function [ dist ] = distanciaE(p1, p2)
%
%

dist = norm(p1 - p2);

end

